Hello and thank you for taking the time to review the materials on my GitHub.

Due to GitHub's size limit the application's installer can be found here:
https://drive.google.com/file/d/18Lgk1yLWbE1NCmVjKwbuQ4poc0u9ckuZ/view?usp=sharing


This project has to be the most important project of my college career, as I put my knowledge to
C# and database systems to the test, this class encouraged me to do a great amount of research
to contribute to my existing knowledge in C#.

My team and I created a WPF learning based application for senior citizens, although it has room
for improvement, I was able to learn able agile development and how to completed a system in
five two-week sprint intervals.

I had the responsibility of bringing my team members ideas to life in C# code.

I constructed the welcome screen and main menu interface off of all of our collective ideas,
and formatted any code contributions from other team members to fit within our application.

Components that I did not code, but had to reformat in order to fit within our application includes:

Evaluation Template
Glossary Page
Demonstration Videos Page

I myself also had the responsibility of incorporating a relational database system within our 
project which allowed for saved user settings, progress tracking through achievements, and
user selection screen.

The documents provided such as "Completed System Images", "Prototype Sketches"
and "Description" are all documents that I had created myself to showcase our project.

All graphics seen were either images taken from Google, or created by myself in Photoshop.