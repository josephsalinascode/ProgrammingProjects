C++ Stack and Queue

To start this application open the Assignment4.sln project file and run the
program.

The program will simply display results from testing performed in the
Main.cpp file

The code exhibited is a array based implementation of a Stack and linked-list
implementation of a Queue. 
