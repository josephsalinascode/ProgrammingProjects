//****************************************************
// File: Main.cpp
//
// Purpose: Main, used to test various methods 
//			depending on the current assignment.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 4.0
//
// Update Information
// ------------------
// Joseph Salinas
// 11/15 - Main will now be used to test
//		   instances of both the PurchaseQueue
//		   and PurchaseStack classes.
//
//
// Joseph Salinas
// 10/22 - Main will now be used to test all 
//		  functions of the PurchaseList class.
//
// Joseph Salinas
// 9/29 - Main will now be used to test all 
//		  functions of the PurchaseCollection class.
//
//****************************************************

#include <iostream>
#include <fstream>
#include "Purchase.h"
#include "PurchaseStack.h"
#include "PurchaseQueue.h"

using namespace std;

//********************************************************
// Function: main
//
// Purpose: Code stored inside main to test the
//			multiple functions of the PurchaseQueue and
//			PurchaseStack class.
//
// Runtime: O(n)
//
//********************************************************
int main()
{
	//Testing Purchase == Operator
	Purchase pt1("Dog", 20, 20);
	Purchase pt2("Dog", 20, 20);

	cout << "******************************************" << endl;
	cout << "Testing Purchase Overloaded == Operator" << endl;
	cout << "******************************************" << endl;
	cout << endl;
	if (pt1 == pt2)
	{
		cout << "Purchases are the same!" << endl;
	}
	else
		cout << "Purchases are different!" << endl;
	cout << endl;

	//Stack Testing
	Purchase p("Cake", 10, 20), p2("Cookie", 20, 40), p3("Sandwich", 30, 90);
	PurchaseStack ps;
	ps.Push(p);
	ps.Push(p2);
	ps.Push(p3);
	Purchase temp;
	cout << "******************************************" << endl;
	cout << "Testing Push on PurchaseStack variable ps:" << endl;
	cout << "******************************************" << endl;
	cout << endl;
	cout << "Current Stack Data" << endl;
	cout << "------------------" << endl;
	cout << ps << endl;
	cout << "Logical Size: " << ps.Size() << endl;
	cout << "Max Storage: " << ps.MaxStorage() << endl;
	cout << endl;
	cout << "Top Data" << endl;
	cout << "--------" << endl;
	ps.Top(temp);
	cout << temp << endl;

	ps.Pop();
	cout << "******************************************" << endl;
	cout << "Testing Pop on PurchaseStack variable ps:" << endl;
	cout << "******************************************" << endl;
	cout << endl;
	cout << "Current Stack Data" << endl;
	cout << "------------------" << endl;
	cout << ps << endl;
	cout << "Logical Size: " << ps.Size() << endl;
	cout << "Max Storage: " << ps.MaxStorage() << endl;
	cout << endl;
	cout << "Top Data" << endl;
	cout << "--------" << endl;
	ps.Top(temp);
	cout << temp << endl;

	PurchaseStack copyStack(ps);
	cout << "************************************************************" << endl;
	cout << "Testing PurchaseStack Copy Constructor" << endl;
	cout << "************************************************************" << endl;
	cout << endl;
	cout << "Current Stack Data" << endl;
	cout << "------------------" << endl;
	cout << copyStack << endl;
	cout << "Logical Size: " << copyStack.Size() << endl;
	cout << "Max Storage: " << copyStack.MaxStorage() << endl;
	cout << endl;
	cout << "Top Data" << endl;
	cout << "--------" << endl;
	copyStack.Top(temp);
	cout << temp << endl;

	PurchaseStack ps20(20);
	ps20.Push(p);
	cout << "************************************************************" << endl;
	cout << "Testing PurchaseStack Overloaded Constructor variable ps20:" << endl;
	cout << "************************************************************" << endl;
	cout << endl;
	cout << "Current Stack Data" << endl;
	cout << "------------------" << endl;
	cout << ps20 << endl;
	cout << "Logical Size: " << ps20.Size() << endl;
	cout << "Max Storage: " << ps20.MaxStorage() << endl;
	cout << endl;
	cout << "Top Data" << endl;
	cout << "--------" << endl;
	ps20.Top(temp);
	cout << temp << endl;

	cout << "************************************************************" << endl;
	cout << "Testing PurchaseStack Overloaded = Operator (ps20 = ps)" << endl;
	cout << "************************************************************" << endl;
	cout << endl;
	ps20 = ps;
	cout << "Current Stack Data" << endl;
	cout << "------------------" << endl;
	cout << ps20 << endl;
	cout << "Logical Size: " << ps20.Size() << endl;
	cout << "Max Storage: " << ps20.MaxStorage() << endl;
	cout << endl;
	cout << "Top Data" << endl;
	cout << "--------" << endl;
	ps20.Top(temp);
	cout << temp << endl;

	Purchase tempClear;
	cout << "************************************************************" << endl;
	cout << "Testing PurchaseStack Clear on ps variable" << endl;
	cout << "************************************************************" << endl;
	cout << endl;
	ps.Clear();
	cout << "Current Stack Data" << endl;
	cout << "------------------" << endl;
	cout << ps << endl;
	cout << "Logical Size: " << ps.Size() << endl;
	cout << "Max Storage: " << ps.MaxStorage() << endl;
	cout << endl;
	cout << "Top Data" << endl;
	cout << "--------" << endl;
	ps.Top(tempClear);
	cout << tempClear << endl;
	cout << endl;
	
	//Queue Testing
	PurchaseQueue pq;
	pq.Enqueue(p);
	pq.Enqueue(p2);
	pq.Enqueue(p3);
	cout << "********************************************" << endl;
	cout << "Testing PurchaseQueue Enqueue on pq variable" << endl;
	cout << "********************************************" << endl;
	cout << endl;
	cout << "Queue Data" << endl;
	cout << "----------" << endl;
	cout << pq << endl;
	cout << "Queue Size: " << pq.Size() << endl;

	Purchase tempQueue;
	bool deQueue = pq.Dequeue(tempQueue);
	cout << endl;
	cout << "********************************************" << endl;
	cout << "Testing PurchaseQueue Dequeue on pq variable" << endl;
	cout << "********************************************" << endl;
	cout << endl;
	cout << "Queue Data" << endl;
	cout << "----------" << endl;
	cout << pq << endl;
	cout << "Queue Size: " << pq.Size() << "\n" << endl;
	cout << "Data DeQueued" << "\n-------------\n" << tempQueue << endl;
	cout << "DeQueue Bool Data: " << deQueue << endl;

	PurchaseQueue copyQueue(pq);
	cout << endl;
	cout << "****************************************************" << endl;
	cout << "Testing PurchaseQueue Copy Constructor copyQueue(pq)" << endl;
	cout << "****************************************************" << endl;
	cout << endl;
	cout << "Queue Data" << endl;
	cout << "----------" << endl;
	cout << copyQueue << endl;
	cout << "Queue Size: " << copyQueue.Size() << "\n" << endl;

	PurchaseQueue pq2;
	pq2 = pq;
	cout << endl;
	cout << "****************************************************" << endl;
	cout << "Testing PurchaseQueue overloaded = (pq2 = pq)" << endl;
	cout << "****************************************************" << endl;
	cout << endl;
	cout << "Queue Data" << endl;
	cout << "----------" << endl;
	cout << pq2 << endl;
	cout << "Queue Size: " << pq2.Size() << "\n" << endl;

	pq.Clear();
	cout << endl;
	cout << "****************************************************" << endl;
	cout << "Testing PurchaseQueue Clear on pq variable" << endl;
	cout << "****************************************************" << endl;
	cout << endl;
	cout << "Queue Data" << endl;
	cout << "----------" << endl;
	cout << pq << endl;
	cout << "Queue Size: " << pq.Size() << "\n" << endl;
	system("pause");
}