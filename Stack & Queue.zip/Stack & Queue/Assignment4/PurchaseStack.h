//**********************************************************
// File: PurchaseStack.h
//
// Purpose: A header file for the PurchaseStack class,
//			holds function declarations that will be
//			for the class.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 1.0
//
// Update Information
// ------------------
// No updates have been performed.
//
//**********************************************************


#ifndef PURCHASESTACK_H
#define PURCHASESTACK_H
#include "Purchase.h"
#include <iostream>

using namespace std;

class PurchaseStack
{
	private:
		Purchase *items;
		int top;
		int MAX_ITEMS;

	public:
		PurchaseStack();
		PurchaseStack(int max);
		PurchaseStack(const PurchaseStack& rhs);
		~PurchaseStack();
		void Clear();
		int Size();
		int MaxStorage();
		bool Push(Purchase p);
		bool Pop();
		bool Top(Purchase &returnedPurchase);
		PurchaseStack & operator=(const PurchaseStack& rhs);
		friend ostream& operator<<(ostream& os, PurchaseStack& ps);
};

#endif;