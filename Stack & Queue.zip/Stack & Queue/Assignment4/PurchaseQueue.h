//**********************************************************
// File: PurchaseQueue.h
//
// Purpose: A header file for the PurchaseQueue class,
//			holds function declarations that will be
//			for the class.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 1.0
//
// Update Information
// ------------------
// No updates have been performed.
//
//**********************************************************


#ifndef PURCHASEQUEUE_H
#define PURCHASEQUEUE_H

#include <iostream>
#include "Purchase.h"

using namespace std;


struct NodeType
{
	Purchase data;
	NodeType* next;
};

class PurchaseQueue
{
	private:

		NodeType* front;
		NodeType* rear;
		int length;

	public:
		PurchaseQueue();
		PurchaseQueue(const PurchaseQueue& rhs);
		~PurchaseQueue();
		void Clear();
		int Size();
		void Enqueue(Purchase p);
		bool Dequeue(Purchase& returnedPurchase);
		PurchaseQueue & operator=(const PurchaseQueue& rhs);
		friend ostream& operator<<(ostream& os, PurchaseQueue& rhs);
};

#endif