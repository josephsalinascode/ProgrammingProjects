//********************************************************
// File: PurchaseQueue.cpp
//
// Purpose: A .cpp file for the PurchaseQueue class,
//			holds function definitions that will be
//			used to mainpulated data. This file contains
//			various methos to perform actions upon the
//			class' queue instance.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 1.0
//
// Update Information
// ------------------
// No updates have been performed.
//
//*********************************************************


#include "PurchaseQueue.h"

//***************************************************************
// Function: PurchaseQueue (Default Constructor)
//
// Purpose: Used to set the front, rear and length variables to
//			default values.
//
// Runtime: O(1)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
PurchaseQueue::PurchaseQueue()
{
	front = NULL;
	rear = NULL;
	length = 0;
}

//***************************************************************
// Function: PurchaseQueue (Copy Constructor)
//
// Purpose: Used to copy all data from the rhs
//			into the current instance's queue.
//
// Runtime: O(n)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
PurchaseQueue::PurchaseQueue(const PurchaseQueue & rhs)
{
	front = NULL;
	rear = NULL;
	length = 0;
	*this = rhs;
}

//***************************************************************
// Function: PurchaseQueue (Destructor)
//
// Purpose: Releases memory from each node within the 
//			current instance's queue.
//
// Runtime: O(n)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
PurchaseQueue::~PurchaseQueue()
{
	Clear();
}

//***************************************************************
// Function: Clear
//
// Purpose: Releases memory from each node within the 
//			current instance's queue, clears the current
//			instance's queue.
//
// Runtime: O(n)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
void PurchaseQueue::Clear()
{
	NodeType *location;

	while (front != NULL)
	{
		location = front;
		front = front->next;
		delete location;
		length--;
	}
	rear = NULL;
}

//***************************************************************
// Function: Size
//
// Purpose: Returns the length of the current instance's queue.
//
// Runtime: O(1)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
int PurchaseQueue::Size()
{
	return length;
}

//***************************************************************
// Function: Enqueue
//
// Purpose: Adds a new node containing the passed-in Purchase 
//			instance as it's data to the rear of the queue
//			of the current instance.
//
// Runtime: O(1)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
void PurchaseQueue::Enqueue(Purchase p)
{
	NodeType *temp;
	temp = new NodeType;

	temp->data = p;
	temp->next = NULL;
	if (rear == NULL)
	{
		front = temp;
	}
	else
	{
		rear->next = temp;
	}
	rear = temp;
	length++;
}

//***************************************************************
// Function: Dequeue
//
// Purpose: Removes the node that is at the front of
//			the queue, sets the reference parameter of
//			returnedPurchase to the Purchase data of
//			the node removed.
//
// Runtime: O(1)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
bool PurchaseQueue::Dequeue(Purchase & returnedPurchase)
{
	if (front == NULL)
	{
		return false;
	}
	NodeType *location = front;
	returnedPurchase = location->data;
	front = front->next;
	if (front == NULL)
	{
		rear = NULL;
	}
	delete location;
	length--;
	return true;
}

//***************************************************************
// Function: Overloaded Operator =
//
// Purpose: Used to perform a deep copy, copying all data from
//			the rhs variable into the current instance.
//
// Runtime: O(n)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
PurchaseQueue & PurchaseQueue::operator=(const PurchaseQueue & rhs)
{
	Clear();
	NodeType *location = rhs.front;
	Purchase temp;

	while (location != NULL)
	{
		temp = location->data;
		Enqueue(temp); //Enqueue will automatically increase length
		location = location->next;
	}

	return *this;
}

//***************************************************************
// Function: Overloaded Operator <<
//
// Purpose: Prints out each Purchase instance on the
//			rhs' queue.
//
// Runtime: O(n)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
ostream & operator<<(ostream & os, PurchaseQueue & rhs)
{
	NodeType *location = rhs.front;

	while (location != NULL)
	{
		os << location->data << endl;
		location = location->next;
	}

	return os;
}
