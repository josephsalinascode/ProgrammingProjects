//********************************************************
// File: PurchaseStack.cpp
//
// Purpose: A .cpp file for the PurchaseStack class,
//			holds function definitions that will be
//			used to mainpulated data. This file contains
//			various methos to perform actions upon the
//			class' stack instance.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 1.0
//
// Update Information
// ------------------
// No updates have been performed.
//
//*********************************************************


#include <iostream>
#include "PurchaseStack.h"

using namespace std;

//***************************************************************
// Function: PurchaseStack (Default Constructor)
//
// Purpose: Used to set the MAX_ITEMS, and top variables to default
//			values. Also allocates items to the size of the MAX_ITEMS 
//			for the current stack instance.
//
// Runtime: O(1)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
PurchaseStack::PurchaseStack()
{
	MAX_ITEMS = 10;
	top = -1;
	items = new Purchase[MAX_ITEMS];
}

//***************************************************************
// Function: PurchaseStack (int max) - Overloaded Constructor
//
// Purpose: Used to set the top to -1, and the MAX_ITEMS
//			variable to the size specified by the user through max.
//			items will now initalized to the max value,
//			that is passed into the method.
//			
//
// Runtime: O(1)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
PurchaseStack::PurchaseStack(int max)
{
	MAX_ITEMS = max;
	top = -1;
	items = new Purchase[max];
}

//***************************************************************
// Function: PurchaseStack (Copy Constructor)
//
// Purpose: Used to perform a deep copy, copying all data from
//			the rhs variable into the current instance.
//
// Runtime: O(n)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
PurchaseStack::PurchaseStack(const PurchaseStack& rhs)
{
	//Setting current instance to default values
	MAX_ITEMS = 10;
	items = new Purchase[MAX_ITEMS];
	top = -1;
	*this = rhs;
}

//***************************************************************
// Function: PurchaseStack (Destructor)
//
// Purpose: Used to deallocate memory for each Purchase instance
//			within the current stack.
//
// Runtime: O(n)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
PurchaseStack::~PurchaseStack()
{
	delete [] items;
}

//***************************************************************
// Function: Clear
//
// Purpose: Used to logically clear the stack array, by
//			setting the top to -1.
//
// Runtime: O(1)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
void PurchaseStack::Clear()
{
	top = -1;
}

//***************************************************************
// Function: Size
//
// Purpose: Returns the logical size of the stack array.
//
// Runtime: O(1)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
int PurchaseStack::Size()
{
	//***************************************************************
	//By default the top is positioned at -1, to receive the number
	//of elements within the stack we must add one to the top.
	//***************************************************************
	return top + 1;
}

//***************************************************************
// Function: MaxStorage
//
// Purpose: Returns the Max number of elements that the
//			stack can hold.
//
// Runtime: O(1)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
int PurchaseStack::MaxStorage()
{
	return MAX_ITEMS;
}

//***************************************************************
// Function: Push
//
// Purpose: Pushes the passed-in Purchase instance onto
//			the stack of the current instance.
//
// Runtime: O(1)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
bool PurchaseStack::Push(Purchase p)
{
	//Checks for stack overflow
	if (top == (MAX_ITEMS - 1))
	{
		return false;
	}
	else
	{
		top++;
		items[top] = p;
		return true;
	}
}

//***************************************************************
// Function: Pop
//
// Purpose: Pops off the Purchase instance that is located
//			at the top of the stack.
//
// Runtime: O(1)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
bool PurchaseStack::Pop()
{
	//Checks for stack underflow
	if (top == -1)
	{
		return false;
	}
	else
	{
		top--;
		return true;
	}
}

//***************************************************************
// Function: Top
//
// Purpose: Returns false if the stack is logically empty,
//			otherwise returns true and sets the top Purchase 
//			instance to the returnedPurchase reference parameter.
//
// Runtime: O(1)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
bool PurchaseStack::Top(Purchase & returnedPurchase)
{
	if (top == -1)
	{
		return false;
	}
	else
	{
		returnedPurchase = items[top];
		return true;
	}
}

//***************************************************************
// Function: Overloaded Operator =
//
// Purpose: Used to perform a deep copy, copying all data from
//			the rhs variable into the current instance.
//
// Runtime: O(n)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
PurchaseStack & PurchaseStack::operator=(const PurchaseStack & rhs)
{
	//Clears any existing data
	Clear();
	//**********************************************************
	//If statement to check if current MAX_ITEMS size matches
	//MAX_ITEMS on the rhs, if not the current instance
	//will be resized accordingly
	//**********************************************************
	if (MAX_ITEMS != rhs.MAX_ITEMS)
	{
		delete[] items;
		items = new Purchase[rhs.MAX_ITEMS];
		MAX_ITEMS = rhs.MAX_ITEMS;
	}
	//*********************************************************
	//A temporary PurchaseStack instance that will be used
	//to obtain data from the rhs.items.
	//*********************************************************
	PurchaseStack ps;
	ps.items = new Purchase[rhs.MAX_ITEMS];
	//**************************************************************
	//This loop will replicate the behavior of pushing/poping 
	//the rhs so that we can easily push/pop the ps variable
	//onto the current instance; being that we can't call methods 
	//on the rhs directly, or data on the rhs could become corrupted.
	//***************************************************************
	for (int i = rhs.top; i != -1; i--)
	{
		ps.Push(rhs.items[i]);
	}
	//*************************************************
	//Temporary Purchase variable, will be used to
	//push the top Purchase instance onto the current
	//instance's stack.
	//*************************************************
	Purchase purc;
	//******************************************************************
	//Using the temporary PurchaseStack variable, ps, Purchase instances
	//will be pushed onto the current instance's stack.
	//******************************************************************
	while (ps.top != -1)
	{
		ps.Top(purc);
		Push(purc);
		ps.Pop();
	}
	return *this;
}

//***************************************************************
// Function: Overloaded Operator <<
//
// Purpose: Prints out each Purchase instance on the
//			rhs' stack.
//
// Runtime: O(n)
//			
// Update Information
// ------------------
// No updates have been performed.
//
//***************************************************************
ostream & operator<<(ostream & os, PurchaseStack &rhs)
{
	int i = 0;
	for (i = rhs.top; i != -1; i--)
	{
		os << rhs.items[i] << endl;
	}
	return os;
}
