//********************************************************
// File: Purchase.cpp
//
// Purpose: A .cpp file for the Purchase class,
//			holds function definitions that will be
//			used to mainpulated data. This file contains
//			Get/Set methods for the class' private member
//			variables and overloaded constructors and
//			overloaded operators.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 3.0
//
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 11/15
// Description: Overloaded == operator was included.
//
// Name: Joseph Salinas
// Date: 9/29
// Description: The class now features pointer member
//				variables, previous methods were adjusted
//				to accommodate for pointers. Destructor
//				and overloaded >> were implemented.
//
//*********************************************************

#include "Purchase.h"
#include <iostream>

using namespace std;

//***************************************************************
// Function: Purchase (Default Constructor)
//
// Purpose: Used to set default values for
//			itemName, quantity and itemPrice
//			
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 9/29
// Description: Method adjusted for the changing of
//				the member variables to pointers, alloctes
//				memory and derferences pointers to assign data.
//
//***************************************************************
Purchase::Purchase()
{
	itemName = new string;
	quantity = new double;
	itemPrice = new double;
	*itemName = "";
	*quantity = 0;
	*itemPrice = 0;
}
//***************************************************************
// Function: Purchase (Overloaded Constructor)
//
// Purpose: Used to set itemName, quantity and itemPrice
//			to specified values passed-in to the method
//			from the user.
//			
//
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 9/29
// Description: Method adjusted for the changing of
//				the member variables to pointers, alloctes
//				memory and derferences pointers to assign data.
//
//***************************************************************
Purchase::Purchase(string name, double qty, double price)
{
	itemName = new string;
	quantity = new double;
	itemPrice = new double;
	*itemName = name;
	*quantity = qty;
	*itemPrice = price;
}
//**************************************************************
// Function: Purchase (Copy Constructor)
//
// Purpose: Used to copy member variable values from
//			the passed-in Purchase instance to the 
//			current instance.
//		
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 9/29
// Description: Method adjusted for the changing of
//				the member variables to pointers, alloctes
//				memory and derferences pointers to assign data.
//
//**************************************************************
Purchase::Purchase(const Purchase& object)
{
	itemName = new string;
	quantity = new double;
	itemPrice = new double;
	*itemName = *object.itemName;
	*itemPrice = *object.itemPrice;
	*quantity = *object.quantity;
}
//**************************************************************
// Function: getitemName
//
// Purpose: Returns the itemName value.
//		
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 9/29
// Description: Method adjusted for the changing of
//				the member variables to pointers, alloctes
//				memory and derferences pointers to return data.
//
//**************************************************************
string Purchase::getitemName()
{
	return *itemName;
}
//**************************************************************
// Function: setitemName
//
// Purpose: Sets the itemName variable to a specified
//			value from the user.
//		
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 9/29
// Description: Method adjusted for the changing of
//				the member variables to pointers, alloctes
//				memory and derferences pointers to assign data.
//
//**************************************************************
void Purchase::setitemName(string name)
{
	*itemName = name;
}
//**************************************************************
// Function: getQuantity
//
// Purpose: Returns the quantity value.
//		
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 9/29
// Description: Method adjusted for the changing of
//				the member variables to pointers, alloctes
//				memory and derferences pointers to return data.
//
//**************************************************************
double Purchase::getQuantity()
{
	return *quantity;
}
//**************************************************************
// Function: setQuantity
//
// Purpose: Sets the quantity variable to a specified
//			value from the user.
//		
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 9/29
// Description: Method adjusted for the changing of
//				the member variables to pointers, alloctes
//				memory and derferences pointers to assign data.
//
//**************************************************************
void Purchase::setQuantity(double qty)
{
	*quantity = qty;
}
//****************************************************
// Function: getitemPrice
//
// Purpose: Returns the itemPrice value.
//		
// Update Information
// ------------------
// Joseph Salinas
// 9/29 - Method adjusted for the changing of
//		  the member variables to pointers, now
//		  derferences pointer to return data.
//
//****************************************************
double Purchase::getitemPrice()
{
	return *itemPrice;
}
//*************************************************************
// Function: setitemPrice
//
// Purpose: Sets the itemPrice variable to a specified
//			value from the user.
//		
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 9/29
// Description: Method adjusted for the changing of
//				the member variables to pointers, alloctes
//				memory and derferences pointers to assign data.
//
//*************************************************************
void Purchase::setitemPrice(double price)
{
	*itemPrice = price;
}
//*************************************************************
// Function: Cost
//
// Purpose: Calculates the cost for the purchase,
//			and returns the calculated value.
//		
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 9/29
// Description: Method adjusted for the changing of
//				the member variables to pointers, alloctes
//				memory and derferences pointers to return data.
//
//*************************************************************
double Purchase::Cost()
{
	double cost = (*itemPrice * *quantity);
	return cost;
}
//*************************************************************
// Function: operator=
//
// Purpose: Overloads the assignment operator to
//			copy all member variable values from
//			the passed-in Purchase instance and copies
//			them to the member variables of the current
//			instrance.
//		
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 9/29
// Description: Method adjusted for the changing of
//				the member variables to pointers, alloctes
//				memory and derferences pointers to assign data.
//
//*************************************************************
Purchase& Purchase::operator=(const Purchase &obj)
{
	*itemName = *obj.itemName;
	*quantity = *obj.quantity;
	*itemPrice = *obj.itemPrice;
	return *this;
}
//****************************************************
// Function: operator<<
//
// Purpose: Overloads the insertion operator to
//			print a detailed format of all
//			member variables and their values
//			for the current Purchase instance.
//		
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 9/29
// Description: Method adjusted for the changing of
//				the member variables to pointers, now
//				derferences pointer to print data.
//
//****************************************************
ostream& operator<<(ostream& os, const Purchase& pur)
{
	os << *pur.itemName << "\n" << *pur.quantity << "\n" << *pur.itemPrice << endl;
	return os;
}
//****************************************************
// Function: operator>>
//
// Purpose: Overloads the insertion operator to
//			read-in data to the current instance
//			of the Purchase class.
//		
// Update Information
// ------------------
// No updates have been applied to this method.
//
//****************************************************
istream & operator>>(istream& is, Purchase& pur)
{
	is >> *pur.itemName >> *pur.itemPrice >> *pur.quantity;
	return is;
}

//****************************************************
// Function: operator==
//
// Purpose: Overloads the non-member == operator to
//			compare data between the two Purchase
//			instances.
//		
// Update Information
// ------------------
// No updates have been applied to this method.
//
//****************************************************
bool operator==(Purchase & lhs, Purchase & rhs)
{
	if (*lhs.itemName == *rhs.itemName && *lhs.itemPrice == *rhs.itemPrice && *lhs.quantity == *rhs.quantity)
	{
		return true;
	}
	else
	{
		return false;
	}


}

//****************************************************
// Function: ~Purchase (Destructor)
//
// Purpose: Destructor will release memory from all
//			previously allocated pointer member 
//			variables.
//		
// Update Information
// ------------------
// No updates have been applied to this method.
//
//****************************************************
Purchase::~Purchase()
{
	delete quantity;
	delete itemName;
	delete itemPrice;
}