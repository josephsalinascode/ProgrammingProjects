//****************************************************
// File: Main.cpp
//
// Purpose: Main, used to test various methods 
//			depending on the current assignment.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 5.0
//
// Update Information
// ------------------
// Joseph Salinas
// 12/7  - Main will now be used to test
//		   instances of PurchaseBST
//
// Joseph Salinas
// 11/15 - Main will now be used to test
//		   instances of both the PurchaseQueue
//		   and PurchaseStack classes.
//
//
// Joseph Salinas
// 10/22 - Main will now be used to test all 
//		  functions of the PurchaseList class.
//
// Joseph Salinas
// 9/29 - Main will now be used to test all 
//		  functions of the PurchaseCollection class.
//
//****************************************************

#include <iostream>
#include <fstream>
#include "PurchaseBST.h"


using namespace std;

//********************************************************
// Function: main
//
// Purpose: Code stored inside main to test the
//			multiple functions of the PurchaseQueue and
//			PurchaseStack class.
//
// Runtime: O(n)
//
//********************************************************
int main()
{
	PurchaseBST tree;
	//Purchase instances that will be used throughout testing
	Purchase p("Coffee", 20.00, 30.00);
	Purchase p2("Cake", 10.00, 5.00);
	Purchase p3("Apple", 60.00, 90.00);
	Purchase p4("Danish", 20.00, 40.00);
	tree.Add(p);
	tree.Add(p2);
	tree.Add(p3);
	tree.Add(p4);
	cout << "Testing PurchaseBST Add (Adding p, p2, p3, p4)" << endl;
	cout << "---------------------------------------------------" << endl;
	cout << tree << endl;
	cout << endl;
	PurchaseBST copyTree(tree);
	cout << "Testing PurchaseBST Copy Constructor copyTree(tree)" << endl;
	cout << "---------------------------------------------------" << endl;
	cout << copyTree << endl;
	cout << endl;
	PurchaseBST assignmentTree;
	assignmentTree = tree;
	cout << "Testing PurchaseBST Overloaded = Operator (assignmentTree = tree)" << endl;
	cout << "-----------------------------------------------------------------" << endl;
	cout << assignmentTree << endl;
	cout << endl;
	assignmentTree.Clear();
	cout << "Testing PurchaseBST Clear (assignmentTree.Clear())" << endl;
	cout << "-----------------------------------------------------------------" << endl;
	cout << assignmentTree << endl; //No results should be displayed
	cout << endl;
	cout << "Testing PurchaseBST Size (tree.Size())" << endl;
	cout << "-----------------------------------------------------------------" << endl;
	cout << tree.Size() << endl; 
	cout << endl;
	cout << "Testing PurchaseBST Inorder (tree.Inorder())" << endl;
	cout << "-----------------------------------------------------------------" << endl;
	tree.Inorder();
	cout << endl;
	cout << "Testing PurchaseBST Preorder (tree.Preorder())" << endl;
	cout << "-----------------------------------------------------------------" << endl;
	tree.Preorder();
	cout << endl;
	cout << "Testing PurchaseBST Postorder (tree.Postorder())" << endl;
	cout << "-----------------------------------------------------------------" << endl;
	tree.Postorder();
	cout << endl;
	double cost = 0;
	cout << "Testing PurchaseBST Cost (tree.Cost(\"Apple\", cost))" << endl;
	cout << "-----------------------------------------------------------------" << endl;
	cout << "Boolean Value: " << tree.GetCost("Apple", cost) << endl;
	cout << "Cost: " << cost << endl;
	cout << endl;
	system("pause");
}