//**********************************************************
// File: PurchaseBST.h
//
// Purpose: A header file for the PurchaseBST class,
//			holds function declarations that will be
//			used for the class.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 1.0
//
//**********************************************************

#ifndef PURCHASEBST_H
#define PURCHASEBST_H
#include "Purchase.h"

using namespace std;

struct Node
{
	Purchase info;
	Node* left;
	Node* right;
};

class PurchaseBST
{
	private:
		Node *root;
		//***************************************************************
		//The functions below are the "helper" functions that will be
		//used for their corresponding public functions
		//***************************************************************
		void Clear(Node*& tree);
		void Add(Node*& tree, Purchase p);
		void PrintTree(Node* tree, ostream& out);
		void Preorder(Node* tree);
		void Inorder(Node* tree);
		void Postorder(Node* tree);
		int Size(Node* tree);
		void CopyTree(Node*& copy, const Node* original);
		bool GetCost(Node* tree, string itemName, double& cost);


	public:
		PurchaseBST();
		PurchaseBST(PurchaseBST& rhs);
		~PurchaseBST();
		void Clear();
		int Size();
		void Add(Purchase p);
		void Preorder();
		void Inorder();
		void Postorder();
		bool GetCost(string itemName, double& cost);
		PurchaseBST& operator=(PurchaseBST& rhs);
		friend ostream& operator<<(ostream& os, PurchaseBST& rhs);
};

#endif