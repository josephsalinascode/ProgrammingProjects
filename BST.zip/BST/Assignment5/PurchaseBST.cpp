//********************************************************
// File: PurchaseBST.cpp
//
// Purpose: A .cpp file for the PurchaseBST class,
//			holds function definitions that will be
//			used to perform specific actions for
//			the class.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 1.0
//
//*********************************************************

#include "PurchaseBST.h"
#include <iostream>

//***************************************************
// Function: Clear(Node *& tree)
//
// Purpose: Helper function used to recursively 
//			clear each tree node from the tree of the 
//			current instance.
//
// Runtime Cost: O(n)
//
//***************************************************
void PurchaseBST::Clear(Node *& tree)
{
	if (tree != NULL)
	{
		Clear(tree->left);
		Clear(tree->right);
		delete tree;
	}
}

//***************************************************
// Function: Add(Node *& tree, Purchase p)
//
// Purpose: Helper method used to recursively add a
//			new tree node to the binary search tree of 
//			the passed-in instance.
//
// Runtime Cost: Olog(n)
//
//***************************************************
void PurchaseBST::Add(Node *& tree, Purchase p)
{
	if (tree == NULL)
	{
		tree = new Node;
		tree->right = NULL;
		tree->left = NULL;
		tree->info = p;
	}
	else if (p < tree->info)
	{
		Add(tree->left, p);
	}
	else
	{
		Add(tree->right, p);
	}
}


//***************************************************
// Function: PrintTree(Node *& tree, ostream & out)
//
// Purpose: Helper method used to recursively print 
//			the tree of the passed-in instance.
//
// Runtime Cost: O(n)
//
//***************************************************
void PurchaseBST::PrintTree(Node * tree, ostream & out)
{
	if (tree != NULL)
	{
		PrintTree(tree->left, out);
		out << tree->info;
		PrintTree(tree->right, out);
	}
}

//*************************************************
// Function: Preorder(Node* tree)
//
// Purpose: Helper function used to recursively 
//			print the item name of each purchase
//			within each node of the tree in a
//			preorder traversal.
//
// Runtime Cost: O(n)
//
//*************************************************
void PurchaseBST::Preorder(Node* tree)
{
	if (tree != NULL)
	{
		cout << tree->info.getitemName() << endl;
		Preorder(tree->left);
		Preorder(tree->right);
	}
}

//*************************************************
// Function: Inorder(Node* tree)
//
// Purpose: Helper function used to recursively 
//			print the item name of each purchase
//			within each node of the tree in an
//			inorder traversal.
//
// Runtime Cost: O(n)
//
//*************************************************
void PurchaseBST::Inorder(Node * tree)
{
	if (tree != NULL)
	{
		Inorder(tree->left);
		cout << tree->info.getitemName() << endl;
		Inorder(tree->right);
	}
}

//*************************************************
// Function: Postorder(Node* tree)
//
// Purpose: Helper function used to recursively 
//			print the item name of each purchase
//			within each node of the tree in a
//			postorder traversal.
//
// Runtime Cost: O(n)
//
//*************************************************
void PurchaseBST::Postorder(Node * tree)
{
	if (tree != NULL)
	{
		Postorder(tree->left);
		Postorder(tree->right);
		cout << tree->info.getitemName() << endl;
	}
}

//***************************************************
// Function: Size(Node* tree)
//
// Purpose: Helper function that recursively 
//			retrieves the size of the passed-in
//			tree.
//
// Runtime Cost: O(n)
//
//***************************************************
int PurchaseBST::Size(Node * tree)
{
	if (tree == NULL)
		return 0;
	else
		return Size(tree->left) + Size(tree->right) + 1;
}

//********************************************************
// Function: CopyTree(Node *& copy, const Node * original)
//
// Purpose: Helper function that recursively 
//			copies each node from the original tree
//			into the copy tree.
//
// Runtime Cost: O(n)
//
//********************************************************
void PurchaseBST::CopyTree(Node *& copy, const Node * original)
{
	if (original == NULL)
		copy = NULL;
	else
	{
		copy = new Node;
		copy->info = original->info;
		CopyTree(copy->left, original->left);
		CopyTree(copy->right, original->right);
	}
}

//**************************************************************
// Function: GetCost(Node * tree, string itemName, double &cost)
//
// Purpose: Helper function that recursively 
//			retrieves the Cost depending on the passed-in
//			itemName.
//
// Runtime Cost: O(n)
//
//**************************************************************
bool PurchaseBST::GetCost(Node * tree, string itemName, double &cost)
{
	if (tree == NULL)
		return false;
	else if (tree->info.getitemName() != itemName)
	{
		GetCost(tree->left, itemName, cost);
		GetCost(tree->right, itemName, cost);
		//****************************************************************
		//Additional check to ensure the correct boolean value is returned
		//during method recursion
		//****************************************************************
		if (cost > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else 
	{
		cost = tree->info.Cost();
		return true;
	}
}

//***************************************************
// Function: PurchaseBST (Default Constructor)
//
// Purpose: Used to set the root pointer to NULL,
//			an empty tree will be created when
//			the instance is created.
//
// Runtime Cost: O(1)
//
//***************************************************
PurchaseBST::PurchaseBST()
{
	root = NULL;
}

//***************************************************
// Function: ~PurchaseBST (Copy Constructor)
//
// Purpose: Used to copy the rhs BST instance to 
//			to the current instance.
//
// Runtime Cost: O(n)
//
//***************************************************
PurchaseBST::PurchaseBST(PurchaseBST & rhs)
{
	//*****************************************
	//Only this line is necessary, Clear in
	//overloaded = will make the current root
	//instance equal to NULL, then will add
	//the rhs's data.
	//*****************************************
	*this = rhs;
}

//***************************************************
// Function: ~PurchaseBST (Destructor)
//
// Purpose: Used to release memory from all
//			existing nodes in the tree.
//
// Runtime Cost: O(n)
//
//***************************************************
PurchaseBST::~PurchaseBST()
{
	Clear();
}

//***************************************************
// Function: Clear(Node *& tree)
//
// Purpose: Used to recursively clear each tree node
//			from the tree of the current instance.
//
// Runtime Cost: O(n)
//
//***************************************************
void PurchaseBST::Clear()
{
	Clear(root);
	root = NULL;
}

//***************************************************
// Function: Size
//
// Purpose: Used to return the size of the binary
//			search tree (number of nodes inside tree).
//
// Runtime Cost: O(n)
//
//***************************************************
int PurchaseBST::Size()
{
	return Size(root);
}

//*************************************************
// Function: Add
//
// Purpose: Used to add a node into the current
//			instance's tree.
//
// Runtime Cost: O(n)
//
//*************************************************
void PurchaseBST::Add(Purchase p)
{
	Add(root, p);
}

//*************************************************
// Function: Preorder
//
// Purpose: Used to print out the item names of
//			each purchase(info) of each node in
//			the current instance's tree
//			through a preorder traversal.
//
// Runtime Cost: O(n)
//
//*************************************************
void PurchaseBST::Preorder()
{
	Preorder(root);
}

//*************************************************
// Function: Inorder
//
// Purpose: Used to print out the item names of
//			each purchase(info) of each node in
//			the current instance's tree
//			through an inorder traversal.
//
// Runtime Cost: O(n)
//
//*************************************************
void PurchaseBST::Inorder()
{
	Inorder(root);
}

//*************************************************
// Function: Postorder
//
// Purpose: Used to print out the item names of
//			each purchase(info) of each node in
//			the current instance's tree
//			through an postorder traversal.
//
// Runtime Cost: O(n)
//
//*************************************************
void PurchaseBST::Postorder()
{
	Postorder(root);
}

//*************************************************
// Function: GetOrder
//
// Purpose: Returns the Cost value of the passed-in
//			itemName if found and returns true,
//			otherwise function will return false.
//
// Runtime Cost: O(n)
//
//*************************************************
bool PurchaseBST::GetCost(string itemName, double & cost)
{
	return GetCost(root, itemName, cost);
}

//****************************************************
// Function: operator==
//
// Purpose: Overloads the assignment operator to
//			copy data from the rhs into the 
//			current instance, creating an
//			exact copy.
//
// Runtime Cost: O(n)
//
//****************************************************
PurchaseBST & PurchaseBST::operator=(PurchaseBST & rhs)
{
	Clear();
	CopyTree(root, rhs.root);
	return *this;
}

//****************************************************
// Function: operator<<
//
// Purpose: Overloads the insertion operator to
//			print the data of each node within the
//			the tree of the passed-in instance.
//
// Runtime Cost: O(n)
//
//****************************************************
ostream & operator<<(ostream & os, PurchaseBST & rhs)
{
	rhs.PrintTree(rhs.root, os);
	return os;
}