//**********************************************************
// File: Purchase.h
//
// Purpose: A header file for the Purchase class,
//			holds function declarations that will be
//			for the class.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 2.0
//
// Update Information
// ------------------
// Name: Joseph Salinas
// Date: 9/29
// Description: The class now features pointer member
//				variables, previous methods were adjusted
//				to accommodate for pointers. Destructor
//				and overloaded >> were added.
//
//**********************************************************

#include <string>
#ifndef PURCHASE_H
#define PURCHASE_H

using namespace std;

class Purchase
{
private:
	string *itemName;
	double *quantity;
	double *itemPrice;

public:
	Purchase();
	Purchase(string name, double qty, double price);
	Purchase(const Purchase& object);
	string getitemName();
	void setitemName(string name);
	double getQuantity();
	void setQuantity(double qty);
	double getitemPrice();
	void setitemPrice(double price);
	double Cost();
	Purchase& operator=(const Purchase &obj);
	//***************************************************************
	//Non-member overload using friend declaration, allows access to 
	//private member variables within function definition. Makes
	//outputting of values easier.
	//***************************************************************
	friend ostream& operator<<(ostream& os, const Purchase &pur);
	friend istream& operator>>(istream& is, Purchase &pur);
	~Purchase();
};

#endif