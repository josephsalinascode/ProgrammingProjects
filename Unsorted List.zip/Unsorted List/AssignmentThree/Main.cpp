//****************************************************
// File: Main.cpp
//
// Purpose: Used to unit test multiple methods from the
//			Purchase and PurchaseCollection classes.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 3.0
//
// Update Information
// ------------------
// Joseph Salinas
// 10/22 - Main will now be used to test all 
//		  functions of the PurchaseList class.
//
// Joseph Salinas
// 9/29 - Main will now be used to test all 
//		  functions of the PurchaseCollection class.
//
//****************************************************

#include <iostream>
#include <fstream>
#include "Purchase.h"
#include "PurchaseList.h"

using namespace std;

//********************************************************
// Function: main
//
// Purpose: Code stored inside main to test the
//			multiple functions of the PurchaseList class.
//
// Runtime: O(n)
//
//********************************************************
int main()
{
	//Purchase instances that will be used for testing.
	Purchase p1("Cookie", 20, 20), p2("Coffee", 30, 30), p3("Tiramisu", 40, 40), p4("Cannoli", 50, 50);
	PurchaseList PL;
	cout << "Testing PL.Add(PurchaseInstance)" << endl;
	cout << "--------------------------------" << endl;
	PL.Add(p1);
	PL.Add(p2);
	cout << PL;
	cout << "Testing Copy Constructor CopyPL(PL)" << endl;
	cout << "-----------------------------------" << endl;
	PurchaseList CopyPL(PL);
	cout << CopyPL;
	cout << "Testing overloaded = operator" << endl;
	cout << "-----------------------------" << endl;
	PurchaseList TestPL;
	TestPL = PL;
	cout << TestPL;
	cout << "Testing PurchaseList Clear" << endl;
	cout << "--------------------------" << endl;
	PL.Clear();
	cout << PL; //No output will be provided, since list is properly cleared.
	cout << PL.Length() << endl;
	cout << endl;
	//Adding p1 and p2 back into PL after the Clear test was performed.
	PL.Add(p1);
	PL.Add(p2);
	PurchaseList otherPL;
	otherPL.Add(p3);
	otherPL.Add(p4);
	cout << "Testing PL.Add(otherPL)" << endl;
	cout << "-----------------------" << endl;
	PL.Add(otherPL);
	cout << PL;
	cout << "***************************" << endl;
	cout << "Testing PurchaseList Delete" << endl;
	cout << "***************************" << endl;
	cout << endl;
	cout << "PL Data/Length Before Delete" << endl;
	cout << "----------------------------" << endl;
	cout << PL;
	cout << PL.Length() << endl;
	cout << endl;
	PL.Delete("Cookie");
	cout << "PL Data/Length After Delete" << endl;
	cout << "----------------------------" << endl;
	cout << PL;
	cout << PL.Length() << endl;
	cout << endl;
	ifstream inputFile;
	inputFile.open("PurchaseFile.txt");
	PurchaseList PLFromFile;
	inputFile >> PLFromFile;
	cout << "Testing overloaded >> operator" << endl;
	cout << "------------------------------" << endl;
	cout << PLFromFile;
	cout << PLFromFile.Length() << endl;
	system("pause");
}