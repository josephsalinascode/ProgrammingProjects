//*************************************************************
// File: PurchaseList.cpp
//
// Purpose: A source file for the PurchaseList class.
//			Contains method definitions that will manage or 
//			alter data within the link-list implementation of 
//			the Purchase class. 
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 1.0
//
// Update Information
// ------------------
// No updates have been implement as of yet.
//
//*************************************************************

#include "PurchaseList.h"
#include <iostream>

//***************************************************************
// Function: PurchaseList (Default Constructor)
//
// Purpose: Used to set the head of the linked-list to a default
//			value of NULL, and length to a default value of 0.
//			
// Runtime Costs: O(1)
//
// Update Information
// ------------------
// No updates have been performed on this method.
//
//***************************************************************
PurchaseList::PurchaseList()
{
	length = 0;
	listData = NULL;
}

//*******************************************************************
// Function: PurchaseList (Copy Constructor)
//
// Purpose: Used to copy the data from all nodes of a linked listed 
//			into the current instance's linked list implementation.
//			
// Runtime Costs: O(n)
//
// Update Information
// ------------------
// No updates have been performed on this method.
//
//********************************************************************
PurchaseList::PurchaseList(const PurchaseList& otherList)
{

	PurchaseListNode *location = otherList.listData;
	length = 0;
	//Adds data from otherList to the current instance
	while (location != NULL)
	{
		Add(location->data);
		location = location->next;
	}
}

//*******************************************************************
// Function: PurchaseList (Destructor)
//
// Purpose: Used to release memory from each node within the current
//			instance's linked list.
//			
// Runtime Costs: O(n)
//
// Update Information
// ------------------
// No updates have been performed on this method.
//
//********************************************************************
PurchaseList::~PurchaseList()
{
	//********************************************
	//Calls Clear method which will go to every
	//node and release memory for that node.
	//********************************************
	Clear();
}

//*******************************************************************
// Function: PurchaseList (Operator = overload)
//
// Purpose: Used to overload the = operator, to replace the current
//			instance's linked list with the linked list provided on
//			the right hand side.
//			
// Runtime Costs: O(n)
//
// Update Information
// ------------------
// No updates have been performed on this method.
//
//********************************************************************
PurchaseList& PurchaseList::operator=(PurchaseList& rhs)
{
	//Clears current instance
	this->Clear();
	PurchaseListNode *location = rhs.listData;
	//Adds data from rhs listData into current instance
	while (location != NULL)
	{
		Add(location->data);
		location = location->next;
	}
	//Returns current instance
	return *this;
}

//*******************************************************************
// Function: Clear
//
// Purpose: Used to release memory from each node within the current
//			instance's linked list.
//			
// Runtime Costs: O(n)
//
// Update Information
// ------------------
// No updates have been performed on this method.
//
//********************************************************************
void PurchaseList::Clear()
{
	PurchaseListNode* temp;
	//Visits each node and releases memory
	while (listData != NULL)
	{
		temp = listData;
		listData = listData->next;
		delete temp;
	}
	length = 0;
}

//*******************************************************************
// Function: Length
//
// Purpose: Returns the length of the current instance's linked list
//			in O(1) runtime by simply returning the length member
//			variable.
//			
// Runtime Costs: O(1)
//
// Update Information
// ------------------
// No updates have been performed on this method.
//
//********************************************************************
int PurchaseList::Length() const
{
	//Returns length in O(1) speed
	return length;
}

//*******************************************************************
// Function: Add(const Purchase p)
//
// Purpose: Adds the passed-in Purchase instace into the current
//			instance's linked list.
//			
// Runtime Costs: O(1)
//
// Update Information
// ------------------
// No updates have been performed on this method.
//
//********************************************************************
void PurchaseList::Add(const Purchase p)
{
	//Adds new node to the current instance's listData
	PurchaseListNode *temp;
	temp = new PurchaseListNode;
	temp->data = p;
	temp->next = listData;
	listData = temp;
	length++;
}

//*******************************************************************
// Function: Add(const PurchaseList& otherList)
//
// Purpose: Appends nodes created from data within the otherList 
//			onto the current instance's linked list.
//			
// Runtime Costs: O(n)
//
// Update Information
// ------------------
// No updates have been performed on this method.
//
//********************************************************************
void PurchaseList::Add(const PurchaseList& otherList)
{
	PurchaseListNode *location = otherList.listData;
	//************************************************************
	//While loop that will continue to append data to the current
	//instance's listData from the otherList.listData until NULL
	//is reached in the otherList
	//************************************************************
	while (location != NULL)
	{
		Add(location->data);
		location = location->next;
	}
}

//*******************************************************************
// Function: FindByItemName
//
// Purpose: Locates a node's data depending on the itemName passed-in
//			from the user. The Purchase data is then passed back
//			through the result reference parameter and will return
//			true if the data is found, or will just return false
//			if the data can't be located.
//			
// Runtime Costs: O(n)
//
// Update Information
// ------------------
// No updates have been performed on this method.
//
//********************************************************************
bool PurchaseList::FindByItemName(std::string itemName, Purchase &result) const
{
	PurchaseListNode *location = listData;
	//***************************************************************************
	//Visits each node to find matching itemName data, sets result
	//reference parameter to found instance and returns true, or returns false.
	//***************************************************************************
	while (listData != NULL)
	{
		if (itemName == location->data.getitemName())
		{
			result = location->data;
			return true;
		}
		else
		{
			location = location->next;
		}
	}
	return false;
}

//*******************************************************************
// Function: Delete
//
// Purpose: Locates a node's data depending on the itemName passed-in
//			from the user. If data corresponding to the itemName is
//			found, that node will be deleted from the current
//			instance's linked list.
//			
// Runtime Costs: O(n)
//
// Update Information
// ------------------
// No updates have been performed on this method.
//
//********************************************************************
void PurchaseList::Delete(string itemName)
{
	PurchaseListNode *location = listData;
	if (itemName == location->data.getitemName())
	{
		listData = listData->next;
		delete location;
		length--;
		return;
	}
	while (location->next != NULL && itemName != (location->next)->data.getitemName())
	{
		location = location->next;
	}
	if (location->next == NULL)
	{
		return;
	}
	PurchaseListNode *templocation = location->next;
	location->next = (location->next)->next;
	delete templocation;
	length--;
}

//*********************************************************************
// Function: Operator << overload
//
// Purpose: Overloads the << member variable for the current instance,
//			prints all purchase data within the linked list to the
//			specified ostream.
//			
// Runtime Costs: O(n)
//
// Update Information
// ------------------
// No updates have been performed on this method.
//
//**********************************************************************
ostream& operator<<(ostream& os, PurchaseList &rhs)
{
	//PurchaseListNode used to visit each node within the rhs.listData
	PurchaseList::PurchaseListNode *location;
	location = rhs.listData;
	//Outputs data for each node
	while (location != NULL)
	{
		os << location->data << endl;
		location = location->next;
	}
	return os;
}

//************************************************************************
// Function: Operator >> overload
//
// Purpose: Overloads the >> non member variable for the passed-in
//			PurchaseList instance. Adds a node for each set of
//			Purchase data specified from the istream.
//			
//			
// Runtime Costs: O(n)
//
// Update Information
// ------------------
// No updates have been performed on this method.
//
//************************************************************************
istream& operator>>(istream& is, PurchaseList &rhs)
{
	//Temp variable to store Purchase data.
	Purchase temp;
	//Clears old data in the rhs linked list.
	rhs.Clear();
	//*************************************************************
	//Will continue to read from input stream, will read from
	//file until the end of the file is reach, or will read
	//from console until the eof ^Z character is entered.
	//*************************************************************
	while (!is.eof())
	{
		is >> temp;
		rhs.Add(temp);
	}
	return is;
}