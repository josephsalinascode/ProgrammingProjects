//*************************************************************
// File: PurchaseList.h
//
// Purpose: A header file for the PurchaseList class.
//			Contains method declarations that will be
//			used for the class.
//
// Written By: Joseph Salinas
//
// Compiler: Visual Studio C++ 2017
//
// Version: 1.0
//
// Update Information
// ------------------
// No updates have been implement as of yet.
//
//*************************************************************

#ifndef PURCHASELIST_H
#define PURCHASELIST _H

#include "Purchase.h"

class PurchaseList
{
	private:

		struct PurchaseListNode
		{
			Purchase data;
			PurchaseListNode *next;
		};

		int length;
		PurchaseListNode *listData;

	public:
		PurchaseList();
		PurchaseList(const PurchaseList& otherList);
		~PurchaseList();
		PurchaseList & operator=(PurchaseList& rhs);
		void Clear();
		int Length() const;
		void Add(const Purchase p);
		void Add(const PurchaseList& otherList);
		bool FindByItemName(std::string itemName, Purchase &result) const;
		void Delete(string itemName);
		friend ostream& operator<<(ostream& os, PurchaseList &rhs);
		friend istream& operator>>(istream& is, PurchaseList &rhs);
};

#endif