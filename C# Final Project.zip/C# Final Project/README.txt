C# Final Project

This was the final project for my C# class. The project encompasses several
topics such as Serialization (expressed in Classes.sln), event handling,
and WPF application creation.

To operate this application, open the CourseScheduleWPF.sln project file
and run the application.

The purpose of this application was to retrieve data from a file and
display the results within the GUI.

First, we the user must retrieve the document containing all the course
information from the courses.json file located within the Debug folder, this
is done by clicking the "Open Course Collection" button and selecting
the the appropriate file (courses.json).

The user can then enter a Course ID within the "Find Course" section within
the text-box right next to "Course Id" (any number between 1-42 will display
a result). In addition, there is a Designator and Number search field where
the user could perform a more advanced search. For example, typing BCS
for "Designator" and 426 for "Number" will display the record for the
C# class.

In addition, when clicking the "Open Professor Collection" button
and opening the professors.json file within the Debug folder, professor
information will be loaded displaying Id, Name, and Phone for each professor.

This class proved to be a great help with my senior project, in which I used
my foundational knowledge from this class in order to teach myself more
advanced topics.
