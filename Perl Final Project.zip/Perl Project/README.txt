Perl Final Project

This project is designed to filter data from an .csv file and display
desired output onto console.

When the script is run, the user will be presented with 13 different choices to
filter and display data from the vgsales.csv file.
