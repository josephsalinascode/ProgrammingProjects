#********************
#Joseph Salinas
#BCS 315
#Perl Final Project
#Project #2
#********************
use 5.13.0;
use warnings;
use strict;
use Term::Menus;
use Term::ANSIColor qw(RESET :constants256 :constants);
use Locale::Currency::Format;
use List::Util qw(max min);
use Time::HiRes qw(gettimeofday);

open (File, "vgsales.csv");
#Variables that will be used amongst the 13 possible if-statements to be utilized.
#%dataHash is the most important element to this project. Hashes are used throughout
#this whole project in order to store data in key, value pairs and to display data.
my %dataHash = ();
#Used for the Term::ANSIColor module, this will keep track of the linenumber,
#and will be incremented in order to result in different coloring of elements
#printed on the console window.
my $linecounter = 1;
my $min = 0;
my $max = 0;
#@list is an array that will hold all the menu item choices, presented to the user.
my @list=('Display top sales for each Year','Display top sales for each Platform'
,'Display top sales for each Genre', 'Display top sales for each Publisher',
'Display top sales by Platform, given the year', 'Display top sales by Genre, given the year',
'Display top sales by Publisher, given the year', 'Display Game with lowest sales',
'Display Game with highest sales', 'Display Platform with highest sales', 'Display Platform with lowest sales',
'Display Year with highest sales', 'Display Year with lowest sales');
my $banner="Video Game Sales Data (NA)";
my $selection=&pick(\@list,$banner);
#*******************************************************************************
#Selection #1 Menu Item, this if-statement will display the top sales for each
#year within the file, excluding years that had 0 sales or are above 2018.
#*******************************************************************************
if ($selection eq 'Display top sales for each Year')
{
    my $t0 = gettimeofday;
    say "";
    say "Top Sales Per Year";
    say "";
    while (defined(my $line=<File>))
    {
      chomp $line;
      #Reads-in data from the file into it's corresponding variable name.
      my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
      $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
      #Regular expressions used to filter out any poorly formated data.
      if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
      if ($year !~ /^[0-9]*$/) {next;}
      #Checks to see if the $NA_Sales are greater than 0 and if the year
      #is less than or equal to 2018. This check is used to ensure clean
      #and valid data.
      if ($NA_Sales != 0 && $year <= 2018)
      {
        $dataHash{$year}+= $NA_Sales;
      }
    }
    print sprintf ("%-10s %s", "Year", "Sales"), "\n";
    print sprintf ("%-10s %s", "-----", "-----"), "\n";
    #Reverses the %dataHash in order to display data from the hash.
    my %reversed = reverse %dataHash;
    for (sort {-($a <=> $b)} keys %reversed)
    {
      my $amt = currency_format('USD', ($_ * 1000000), FMT_NOZEROS);
      if($linecounter % 2 == 0)
      {
        print BOLD WHITE ON_BLUE sprintf("%-10s %s", "$reversed{$_}", "$amt"), RESET, "\n";
        $linecounter++;
      }
      else
      {
        print BOLD WHITE ON_BRIGHT_BLUE sprintf("%-10s %s", "$reversed{$_}", "$amt"), RESET, "\n";
        $linecounter++;
      }
    }
    #$t1 and $t0 are used throughout the if-statements in order to determine the
    #duration of the query, using the Time::HiRes module.
    my $t1 = gettimeofday;
    my $elapsed = $t1-$t0;
    say "";
    say "[Query Run-Time: " . $elapsed . " seconds]";
}
#*******************************************************************************
#Selection #2 Menu Item, this if-statement will display the top sales for each
#platform within the file, excluding platforms that had 0 sales.
#*******************************************************************************
elsif ($selection eq 'Display top sales for each Platform')
{
  my $t0 = gettimeofday;
  say "";
  say "Top Sales Per Platform";
  say "";
  while (defined(my $line=<File>))
  {
    chomp $line;
    #Reads-in data from the file into it's corresponding variable name.
    my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
    $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
    #Regular expressions used to filter out any poorly formated data.
    if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
    if ($year !~ /^[0-9]*$/) {next;}
    #Checks to see if the $NA_Sales are greater than 0.
    #This check is used to ensure clean and valid data.
    if ($NA_Sales != 0 && $year <= 2018)
    {
      $dataHash{$platform}+= $NA_Sales;
    }
  }
  #Reverses the %dataHash in order to display data from the hash.
  my %reversed = reverse %dataHash;
  print sprintf ("%-10s %s", "Platform", "Sales"), "\n";
  print sprintf ("%-10s %s", "--------", "-----"), "\n";
  for (sort {-($a <=> $b)} keys %reversed)
  {
    my $amt = currency_format('USD', ($_ * 1000000), FMT_NOZEROS);
    if($linecounter % 2 == 0)
    {
      print BOLD WHITE ON_BLUE sprintf ("%-10s %s", "$reversed{$_}", "$amt"), RESET, "\n";
      $linecounter++;
    }
    else
    {
      print BOLD WHITE ON_BRIGHT_BLUE sprintf ("%-10s %s", "$reversed{$_}", "$amt"), RESET, "\n";
      $linecounter++;
    }
  }
  my $t1 = gettimeofday;
  my $elapsed = $t1-$t0;
  say "";
  say "[Query Run-Time: " . $elapsed . " seconds]";
}
#*******************************************************************************
#Selection #3 Menu Item, this if-statement will display the top sales for each
#genre within the file, excluding genres that had 0 sales.
#*******************************************************************************
elsif ($selection eq 'Display top sales for each Genre')
{
    my $t0 = gettimeofday;
    say "";
    print sprintf  ("%-2s %s", "", "Top Sales Per Genre"), "\n";
    say "";
    while (defined(my $line=<File>))
    {
      chomp $line;
      #Reads-in data from the file into it's corresponding variable name.
      my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
      $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
      #Regular expressions used to filter out any poorly formated data.
      if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
      if ($year !~ /^[0-9]*$/) {next;}
      #Checks to see if the $NA_Sales are greater than 0.
      #This check is used to ensure clean and valid data.
      if ($NA_Sales != 0 && $year <= 2018)
      {
        $dataHash{$genre}+= $NA_Sales;
      }
    }
    #Reverses the %dataHash in order to display data from the hash.
    my %reversed = reverse %dataHash;
    print sprintf ("%-15s %s", "Genre", "Sales"), "\n";
    print sprintf ("%-15s %s", "-----", "-----"), "\n";
    for (sort {-($a <=> $b)} keys %reversed)
    {
      my $amt = currency_format('USD', ($_ * 1000000), FMT_NOZEROS);
      if($linecounter % 2 eq 0)
      {
        print BOLD WHITE ON_BLUE sprintf ("%-15s %s", "$reversed{$_}", "$amt"), RESET, "\n";
        $linecounter++;
      }
      else
      {
        print BOLD WHITE ON_BRIGHT_BLUE sprintf ("%-15s %s", "$reversed{$_}", "$amt"), RESET, "\n";
        $linecounter++;
      }
    }
    my $t1 = gettimeofday;
    my $elapsed = $t1-$t0;
    say "";
    say "[Query Run-Time: " . $elapsed . " seconds]";
}
#*******************************************************************************
#Selection #4 Menu Item, this if-statement will display the top sales for each
#publisher within the file, excluding publishers that had 0 sales.
#*******************************************************************************
elsif ($selection eq 'Display top sales for each Publisher')
{
    my $t0 = gettimeofday;
    say "";
    print sprintf  ("%-10s %s", "", "Top Sales Per Publisher"), "\n";
    say "";
    while (defined(my $line=<File>))
    {
      chomp $line;
      #Reads-in data from the file into it's corresponding variable name.
      my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
      $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
      #Regular expressions used to filter out any poorly formated data.
      if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
      if ($year !~ /^[0-9]*$/) {next;}
      #Checks to see if the $NA_Sales are greater than 0,
      #This check is used to ensure clean and valid data.
      if ($NA_Sales != 0 && $year <= 2018)
      {
        $dataHash{$publisher} += $NA_Sales;
      }
    }
    #Reverses the %dataHash in order to display data from the hash.
    my %reversed = reverse %dataHash;
    print sprintf ("%-35s %s", "Publisher", "Sales"), "\n";
    print sprintf ("%-35s %s", "---------", "-----"), "\n";
    for (sort {-($a <=> $b)} keys %reversed)
    {
      my $shortened = substr($reversed{$_}, 0, 30);
      my $amt = currency_format('USD', ($_ * 1000000), FMT_NOZEROS);
      if($linecounter % 2 eq 0)
      {
        print BOLD WHITE ON_BLUE sprintf ("%-35s %s", "$shortened", "$amt"), RESET, "\n";
      }
      else
      {
        print BOLD WHITE ON_BRIGHT_BLUE sprintf ("%-35s %s", "$shortened", "$amt"), RESET, "\n";
      }
      $linecounter++;
    }
    my $t1 = gettimeofday;
    my $elapsed = $t1-$t0;
    say "";
    say "[Query Run-Time: " . $elapsed . " seconds]";
}
#*******************************************************************************
#Selection #5 Menu Item, this if-statement will display the top sales for each
#platform within the file in a given year provided by the user, excluding
#platforms that had 0 sales.
#*******************************************************************************
elsif ($selection eq 'Display top sales by Platform, given the year')
{
    my $t0 = gettimeofday;
    say "";
    say "Please enter a year, to show records for top sales per platform for that year.";
    my $Year = <STDIN>;
    chomp $Year;
    say "";
    say "Top Sales Per Platform, in $Year";
    say "";
    while (defined(my $line=<File>))
    {
      chomp $line;
      #Reads-in data from the file into it's corresponding variable name.
      my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
      $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
      #Regular expressions used to filter out any poorly formated data.
      if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
      if ($year !~ /^[0-9]*$/) {next;}
      #Checks to see if the $NA_Sales are greater than 0, and if the year
      #provided by the user matches the current year being read from
      #the file.
      if($year eq $Year && $NA_Sales != 0 && $year <= 2018)
      {
        $dataHash{$platform} += $NA_Sales;
      }
    }
    print sprintf ("%-10s %s", "Platform", "Sales"), "\n";
    print sprintf ("%-10s %s", "--------", "-----"), "\n";
    #Reverses the %dataHash in order to display data from the hash.
    my %reversed = reverse %dataHash;
    for (sort {-($a <=> $b)} keys %reversed)
    {
      my $amt = currency_format('USD', ($_ * 1000000), FMT_NOZEROS);
      if($linecounter % 2 == 0)
      {
        print BOLD WHITE ON_BLUE sprintf ("%-10s %s", "$reversed{$_}", "$amt"), RESET, "\n";
        $linecounter++;
      }
      else
      {
        print BOLD WHITE ON_BRIGHT_BLUE sprintf ("%-10s %s", "$reversed{$_}", "$amt"), RESET, "\n";
        $linecounter++;
      }
    }
    my $t1 = gettimeofday;
    my $elapsed = $t1-$t0;
    say "";
    say "[Query Run-Time: " . $elapsed . " seconds]";
}
#*******************************************************************************
#Selection #6 Menu Item, this if-statement will display the top sales for each
#genre within the file in a given year provided by the user, excluding
#genres that had 0 sales.
#*******************************************************************************
elsif ($selection eq 'Display top sales by Genre, given the year')
{
    my $t0 = gettimeofday;
    say "";
    say "Please enter a year, to show records for top sales per genre for that year.";
    my $Year = <STDIN>;
    chomp $Year;
    say "";
    say "Top Sales Per Genre, in $Year";
    say "";
    while (defined(my $line=<File>))
    {
      chomp $line;
      #Reads-in data from the file into it's corresponding variable name.
      my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
      $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
      #Regular expressions used to filter out any poorly formated data.
      if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
      if ($year !~ /^[0-9]*$/) {next;}
      #Checks to see if the $NA_Sales are greater than 0, and if the year
      #provided by the user matches the current year being read from
      #the file.
      if ($year eq $Year && $NA_Sales != 0 && $year <= 2018)
      {
        $dataHash{$genre}+= $NA_Sales;
      }
    }
    #Reverses the %dataHash in order to display data from the hash.
    my %reversed = reverse %dataHash;
    print sprintf ("%-15s %s", "Genre", "Sales"), "\n";
    print sprintf ("%-15s %s", "-----", "-----"), "\n";
    for (sort {-($a <=> $b)} keys %reversed)
    {
      my $amt = currency_format('USD', ($_ * 1000000), FMT_NOZEROS);
      if ($linecounter % 2 == 0)
      {
        print BOLD WHITE ON_BLUE sprintf ("%-15s %s", "$reversed{$_}", "$amt"), RESET, "\n";
        $linecounter++;
      }
      else
      {
        print BOLD WHITE ON_BRIGHT_BLUE sprintf ("%-15s %s", "$reversed{$_}", "$amt"), RESET, "\n";
        $linecounter++;
      }
    }
    my $t1 = gettimeofday;
    my $elapsed = $t1-$t0;
    say "";
    say "[Query Run-Time: " . $elapsed . " seconds]";
}
#*******************************************************************************
#Selection #7 Menu Item, this if-statement will display the top sales for each
#publisher within the file in a given year provided by the user, excluding
#publishers that had 0 sales.
#*******************************************************************************
elsif ($selection eq 'Display top sales by Publisher, given the year')
{
    my $t0 = gettimeofday;
    say "";
    say "Please enter a year, to show records for top sales per publisher for that year.";
    my $Year = <STDIN>;
    chomp $Year;
    say "";
    print sprintf  ("%-5s %s", "", "Top Sales Per Publisher, in $Year"), "\n";
    say "";
    while (defined(my $line=<File>))
    {
      chomp $line;
      #Reads-in data from the file into it's corresponding variable name.
      my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
      $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
      #Regular expressions used to filter out any poorly formated data.
      if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
      if ($year !~ /^[0-9]*$/) {next;}
      #Checks to see if the $NA_Sales are greater than 0, and if the year
      #provided by the user matches the current year being read from
      #the file.
      if ($NA_Sales != 0 && $year eq $Year && $year <= 2018)
      {
        $dataHash{$publisher} += $NA_Sales;
      }
    }
    #Reverses the %dataHash in order to display data from the hash.
    my %reversed = reverse %dataHash;
    print sprintf ("%-35s %s", "Publisher", "Sales"), "\n";
    print sprintf ("%-35s %s", "---------", "-----"), "\n";
    for (sort {-($a <=> $b)} keys %reversed)
    {
      my $shortened = substr($reversed{$_}, 0, 30);
      my $amt = currency_format('USD', ($_ * 1000000), FMT_NOZEROS);
      if ($linecounter % 2 == 0)
      {
        print BOLD WHITE ON_BLUE sprintf ("%-35s %s", "$shortened", "$amt"), RESET, "\n";
        $linecounter++;
      }
      else
      {
        print BOLD WHITE ON_BRIGHT_BLUE sprintf ("%-35s %s", "$shortened", "$amt"), RESET, "\n";
        $linecounter++;
      }
    }
    my $t1 = gettimeofday;
    my $elapsed = $t1-$t0;
    say "";
    say "[Query Run-Time: " . $elapsed . " seconds]";
}
#*******************************************************************************
#Selection #8 Menu Item, this if-statement will display the game(s) with the
#lowest sales, being that multiple games in this file contain the same
#lowest values, all names containing the lowest value will be presented to the
#user.
#*******************************************************************************
elsif ($selection eq 'Display Game with lowest sales')
{
    my $t0 = gettimeofday;
    while (defined(my $line=<File>))
    {
      chomp $line;
      #Reads-in data from the file into it's corresponding variable name.
      my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
      $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
      #Regular expressions used to filter out any poorly formated data.
      if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
      if ($year !~ /^[0-9]*$/) {next;}
      if ($NA_Sales != 0 && $year <= 2018)
      {
        $dataHash{$gameName}+= $NA_Sales;
      }
    }
    #Utilizes the List::Util module to find the min value in the hash.
    $min = min values %dataHash;
    my $amt = currency_format('USD', ($min * 1000000), FMT_NOZEROS);
    say "";
    say "Record(s) found for lowest game sales with $amt: ";
    say "";
    say "Game Name";
    say "---------";
    for (sort keys %dataHash)
    {
      if ($linecounter % 2 == 0 && $min == $dataHash{$_} )
      {
        print BOLD WHITE ON_BLUE "$_", RESET, "\n";
        $linecounter++;
      }
      elsif($min == $dataHash{$_})
      {
        print BOLD WHITE ON_BRIGHT_BLUE "$_", RESET, "\n";
        $linecounter++;
      }
    }
    my $t1 = gettimeofday;
    my $elapsed = $t1-$t0;
    say "";
    say "[Query Run-Time: " . $elapsed . " seconds]";
}
#*******************************************************************************
#Selection #9 Menu Item, this if-statement will display the game with the
#highest sales within the file.
#*******************************************************************************
elsif ($selection eq 'Display Game with highest sales')
{
    my $t0 = gettimeofday;
    my $highestName;
    my $temp = 0;
    while (defined(my $line=<File>))
    {
      chomp $line;
      #Reads-in data from the file into it's corresponding variable name.
      my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
      $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
      #Regular expressions used to filter out any poorly formated data.
      if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
      if ($year !~ /^[0-9]*$/) {next;}
      if ($NA_Sales != 0 && $year <= 2018)
      {
        $dataHash{$gameName}+= $NA_Sales;
      }
    }
    #Reverses the %dataHash in order to display data from the hash.
    my %reversed = reverse %dataHash;
    #Utilizes the List::Util module to find the max value in the hash.
    $max = max values %dataHash;
    my $shortened = substr($reversed{$max}, 0, 30);
    my $amt = currency_format('USD', ($max * 1000000), FMT_NOZEROS);
    say "";
    print "Record found for the Game with the highest sales:\n";
    say "";
    print sprintf ("%-35s %s", "Game", "Sales"), "\n";
    print sprintf ("%-35s %s", "----", "-----"), "\n";
    print BOLD WHITE ON_BLUE sprintf ("%-35s %s", "$shortened", "$amt"), RESET, "\n";
    my $t1 = gettimeofday;
    my $elapsed = $t1-$t0;
    say "";
    say "[Query Run-Time: " . $elapsed . " seconds]";
}
#*******************************************************************************
#Selection #10 Menu Item, this if-statement will display the platform with the
#highest sales within the file.
#*******************************************************************************
elsif ($selection eq 'Display Platform with highest sales')
{
    my $t0 = gettimeofday;
    while (defined(my $line=<File>))
    {
      chomp $line;
      #Reads-in data from the file into it's corresponding variable name.
      my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
      $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
      #Regular expressions used to filter out any poorly formated data.
      if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
      if ($year !~ /^[0-9]*$/) {next;}
      if ($NA_Sales != 0 && $year <= 2018)
      {
        $dataHash{$platform}+= $NA_Sales;
      }
    }
    #Utilizes the List::Util module to find the max value in the hash.
    $max = max values %dataHash;
    #Reverses the %dataHash in order to display data from the hash using the
    #max value as the key.
    my %reversed = reverse %dataHash;
    my $amt = currency_format('USD', ($max * 1000000), FMT_NOZEROS);
    say "";
    print "Record found for the Platform with the highest sales:\n";
    say "";
    print sprintf ("%-10s %s", "Platform", "Sales"), "\n";
    print sprintf ("%-10s %s", "--------", "-----"), "\n";
    print BOLD WHITE ON_BLUE sprintf ("%-10s %s", "$reversed{$max}", "$amt"), RESET, "\n";
    my $t1 = gettimeofday;
    my $elapsed = $t1-$t0;
    say "";
    say "[Query Run-Time: " . $elapsed . " seconds]";
}
#*******************************************************************************
#Selection #11 Menu Item, this if-statement will display the game with the
#highest sales within the file.
#*******************************************************************************
elsif ($selection eq 'Display Platform with lowest sales')
{
    my $t0 = gettimeofday;
    while (defined(my $line=<File>))
    {
      chomp $line;
      #Reads-in data from the file into it's corresponding variable name.
      my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
      $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
      #Regular expressions used to filter out any poorly formated data.
      if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
      if ($year !~ /^[0-9]*$/) {next;}
      if ($NA_Sales != 0 && $year <= 2018)
      {
        $dataHash{$platform}+= $NA_Sales;
      }
    }
    #Reverses the %dataHash in order to display data from the hash using the
    #min value as the key.
    my %reversed = reverse %dataHash;
    #Utilizes the List::Util module to find the min value in the hash.
    $min = min values %dataHash;
    my $amt = currency_format('USD', ($min * 1000000), FMT_NOZEROS);
    say "";
    print "Record found for the Platform with the lowest sales:\n";
    say "";
    print sprintf ("%-10s %s", "Platform", "Sales"), "\n";
    print sprintf ("%-10s %s", "--------", "-----"), "\n";
    print BOLD WHITE ON_BLUE sprintf ("%-10s %s", "$reversed{$min}", "$amt"), RESET, "\n";
    my $t1 = gettimeofday;
    my $elapsed = $t1-$t0;
    say "";
    say "[Query Run-Time: " . $elapsed . " seconds]";
}
#*******************************************************************************
#Selection #12 Menu Item, this if-statement will display the year with the
#highest sales within the file.
#*******************************************************************************
elsif ($selection eq 'Display Year with highest sales')
{
    my $t0 = gettimeofday;
    while (defined(my $line=<File>))
    {
      chomp $line;
      #Reads-in data from the file into it's corresponding variable name.
      my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
      $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
      #Regular expressions used to filter out any poorly formated data.
      if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
      if ($year !~ /^[0-9]*$/) {next;}
      if ($NA_Sales != 0 && $year <= 2018)
      {
        $dataHash{$year}+= $NA_Sales;
      }
    }
    #Utilizes the List::Util module to find the max value in the hash.
    $max = max values %dataHash;
    #Reverses the %dataHash in order to display data from the hash using the
    #max value as the key.
    my %reversed = reverse %dataHash;
    my $amt = currency_format('USD', ($max * 1000000), FMT_NOZEROS);
    say "";
    print "Record found for the Year with the highest sales:\n";
    say "";
    print sprintf ("%-10s %s", "Year", "Sales"), "\n";
    print sprintf ("%-10s %s", "-----", "-----"), "\n";
    print BOLD WHITE ON_BLUE sprintf("%-10s %s", "$reversed{$max}", "$amt"), RESET, "\n";
    my $t1 = gettimeofday;
    my $elapsed = $t1-$t0;
    say "";
    say "[Query Run-Time: " . $elapsed . " seconds]";
}
#*******************************************************************************
#Selection #13 Menu Item, this if-statement will display the year with the
#lowest sales within the file.
#*******************************************************************************
elsif ($selection eq 'Display Year with lowest sales')
{
    my $t0 = gettimeofday;
    while (defined(my $line=<File>))
    {
      chomp $line;
      #Reads-in data from the file into it's corresponding variable name.
      my ($lineno, $gameName, $platform, $year, $genre, $publisher, $NA_Sales, $EU_Sales,
      $JP_Sales, $Other_Sales, $Global_Sales) = split /,/, $line;
      #Regular expressions used to filter out any poorly formated data.
      if ($NA_Sales !~ /^[0.0-9]*$/) {next;}
      if ($year !~ /^[0-9]*$/) {next;}
      if ($NA_Sales != 0 && $year <= 2018)
      {
        $dataHash{$year}+= $NA_Sales;
      }
    }
    #Utilizes the List::Util module to find the min value in the hash.
    $min = min values %dataHash;
    #Reverses the %dataHash in order to display data from the hash using the
    #min value as the key.
    my %reversed = reverse %dataHash;
    say "";
    print "Record found for the Year with the lowest sales:\n";
    say "";
    my $amt = currency_format('USD', ($min * 1000000), FMT_NOZEROS);
    print sprintf ("%-10s %s", "Year", "Sales"), "\n";
    print sprintf ("%-10s %s", "-----", "-----"), "\n";
    print BOLD WHITE ON_BLUE sprintf("%-10s %s", "$reversed{$min}", "$amt"), RESET, "\n";
    my $t1 = gettimeofday;
    my $elapsed = $t1-$t0;
    say "";
    say "[Query Run-Time: " . $elapsed . " seconds]";
}
close File;
