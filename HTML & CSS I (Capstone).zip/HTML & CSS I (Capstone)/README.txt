HTML & CSS I - Capstone Project

This is my Capstone project for my web development class, by opening
the home.html file, you will be presented with a static website containing
two pages about the music artist Lauv.
